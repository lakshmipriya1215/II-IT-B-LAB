#include<stdio.h>
void bubble_sorting(int [] , int);

int main()
{
    int a[20] , n , i ;
    
    printf(" enter the number of digits\n");
    scanf("%d" , &n);
    printf("%d\n", n);
    
    for(i = 0 ; i < n ; i++)
    {
        scanf("%d" , &a[i]);
    }
    
    bubble_sorting(a , n);
    
    printf("the sorted array is : \n");
    for ( i = 0 ; i < n ; i++)
    {
        printf("%d\t" , a[i]);
    }
    return 0;
}

void bubble_sorting(int a[] , int n)
{
    int i , j , temp ; 
    for ( i = 0 ; i < (n - 1) ; i++)
    {
        for ( j = 0 ; j < (n - i - 1) ; j++)
        {
            if ( a[j] > a[j+1])
            {
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp ;
                
            }
           
        }
    }
}